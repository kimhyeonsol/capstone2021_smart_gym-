package capstone2021.smartGym_backend.service;

public interface ESLServiceImpl {
}
