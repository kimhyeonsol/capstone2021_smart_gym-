package capstone2021.smartGym_backend.DTO.Statistics;

public class StatisticsDTO {
    private String year;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}
