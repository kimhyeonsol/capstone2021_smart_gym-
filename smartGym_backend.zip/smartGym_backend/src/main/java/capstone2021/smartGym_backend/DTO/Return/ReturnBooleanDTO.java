package capstone2021.smartGym_backend.DTO.Return;

public class ReturnBooleanDTO {
    Boolean success=true;
    Boolean data=true;

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Boolean getData() {
        return data;
    }

    public void setData(Boolean data) {
        this.data = data;
    }


}
