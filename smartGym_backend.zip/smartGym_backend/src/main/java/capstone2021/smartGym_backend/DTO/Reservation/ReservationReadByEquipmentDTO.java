package capstone2021.smartGym_backend.DTO.Reservation;

public class ReservationReadByEquipmentDTO {
    private Long equipmentID;

    public Long getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(Long equipmentID) {
        this.equipmentID = equipmentID;
    }
}
