package capstone2021.smartGym_backend.DTO.AllowedUser;

public class AllowedUserReadUserInfoDTO {
    String userID;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
