package capstone2021.smartGym_backend.DTO.Manager;

public class ManagerLoginDTO {
    private String managerPassword;

    public String getManagerPassword() {
        return managerPassword;
    }

    public void setManagerPassword(String managerPassword) {
        this.managerPassword = managerPassword;
    }
}
