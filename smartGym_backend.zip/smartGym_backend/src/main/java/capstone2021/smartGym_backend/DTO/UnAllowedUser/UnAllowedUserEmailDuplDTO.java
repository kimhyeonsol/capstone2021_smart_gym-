package capstone2021.smartGym_backend.DTO.UnAllowedUser;

public class UnAllowedUserEmailDuplDTO {
    private String userEmail;

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}
