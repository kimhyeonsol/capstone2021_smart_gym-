package capstone2021.smartGym_backend.DTO.UnAllowedUser;

public class UnAllowedUserApproveDTO {
    String userID;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
