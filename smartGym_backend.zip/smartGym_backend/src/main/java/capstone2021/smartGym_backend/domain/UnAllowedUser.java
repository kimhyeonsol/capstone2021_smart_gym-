package capstone2021.smartGym_backend.domain;

import javax.persistence.Entity;

@Entity
public class UnAllowedUser extends User{



}
