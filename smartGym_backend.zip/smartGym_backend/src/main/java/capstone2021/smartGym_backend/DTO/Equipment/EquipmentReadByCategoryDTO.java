package capstone2021.smartGym_backend.DTO.Equipment;

public class EquipmentReadByCategoryDTO {
    private String equipmentCategorySelect;

    public String getEquipmentCategorySelect() {
        return equipmentCategorySelect;
    }

    public void setEquipmentCategorySelect(String equipmentCategorySelect) {
        this.equipmentCategorySelect = equipmentCategorySelect;
    }
}
