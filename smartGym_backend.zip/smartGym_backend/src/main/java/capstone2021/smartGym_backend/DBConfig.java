package capstone2021.smartGym_backend;

public class DBConfig {
}
