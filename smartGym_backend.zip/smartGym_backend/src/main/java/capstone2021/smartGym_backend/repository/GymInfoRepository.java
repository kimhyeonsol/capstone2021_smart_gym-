package capstone2021.smartGym_backend.repository;

import capstone2021.smartGym_backend.domain.GymInfo;

public interface GymInfoRepository {
    int update(GymInfo gymInfo);
    GymInfo read();
    boolean equipmentLayoutUpdate(GymInfo gymInfo);
    String equipmentLayoutRead();
}
