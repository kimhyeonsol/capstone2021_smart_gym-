package capstone2021.smartGym_backend.DTO.Equipment;

public class EquipmentDeleteDetailedReadDTO {
    private Long equipmentID;

    public Long getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(Long equipmentID) {
        this.equipmentID = equipmentID;
    }
}
