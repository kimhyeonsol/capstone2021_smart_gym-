package capstone2021.smartGym_backend.repository;

import capstone2021.smartGym_backend.domain.Manager;

public interface ManagerRepository {
    int managerLogin(Manager manager);
}
