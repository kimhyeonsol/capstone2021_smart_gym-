package capstone2021.smartGym_backend.DTO.User;

public class UserDeleteDTO {
    private String userID;
    private String userPW;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserPW() {
        return userPW;
    }

    public void setUserPW(String userPW) {
        this.userPW = userPW;
    }
}
