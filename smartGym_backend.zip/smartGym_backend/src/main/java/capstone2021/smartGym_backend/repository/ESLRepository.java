package capstone2021.smartGym_backend.repository;

public interface ESLRepository {
}
