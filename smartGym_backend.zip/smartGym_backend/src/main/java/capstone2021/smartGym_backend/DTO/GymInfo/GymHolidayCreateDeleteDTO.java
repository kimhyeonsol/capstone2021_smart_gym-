package capstone2021.smartGym_backend.DTO.GymInfo;

public class GymHolidayCreateDeleteDTO {
    private String gymHolidayDate;

    public String getGymHolidayDate() {
        return gymHolidayDate;
    }

    public void setGymHolidayDate(String gymHolidayDate) {
        this.gymHolidayDate = gymHolidayDate;
    }
}
