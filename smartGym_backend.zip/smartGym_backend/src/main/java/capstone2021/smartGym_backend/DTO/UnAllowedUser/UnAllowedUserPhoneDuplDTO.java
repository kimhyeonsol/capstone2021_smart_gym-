package capstone2021.smartGym_backend.DTO.UnAllowedUser;

public class UnAllowedUserPhoneDuplDTO {
    private String userPhone;

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }
}
